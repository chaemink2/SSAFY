// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "MULTI_GUEST"		// replace MySSID with your WiFi network name
#define SECRET_PASS "guest1357"	// replace MyPassword with your WiFi password

#define SECRET_CH_ID 1936189			// replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "MYBLSMJ7SIJ8GRXI"   // replace XYZ with your channel write API Key
