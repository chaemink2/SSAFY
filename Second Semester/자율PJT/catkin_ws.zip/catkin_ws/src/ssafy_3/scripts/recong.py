#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import rospy
import rospkg
from math import cos,sin,pi,sqrt,pow,atan2,atan
from geometry_msgs.msg import Point,PoseWithCovarianceStamped
from nav_msgs.msg import Odometry,Path
from morai_msgs.msg import CtrlCmd,EgoVehicleStatus,ObjectStatusList,GPSMessage
import numpy as np
import tf
from tf.transformations import euler_from_quaternion,quaternion_from_euler
from std_msgs.msg import String

# 시나리오 2
class recong_pub():
    def __init__(self):
        rospy.init_node('recong_pub', anonymous=True)

        rospy.Subscriber("/odom", Odometry, self.odom_callback)
        rospy.Subscriber("/gps",GPSMessage,self.navsat_callback)
        # rospy.Subscriber("/global_path", Path, self.global_path_callback)

        self.recong_pub = rospy.Publisher('recong', String, queue_size=1)

        # self.is_global_path = False
        self.is_gps = False
        self.is_gpson = True
        
        self.current_postion = Point()

        # while True:
        #     if self.is_global_path == True:
        #         self.recong_msg = 'basic'
        #         break
        #     else:
        #         self.recong_msg = 'lanedetect'
                

        # 시나리오 시작좌표
        start_point = (210, 1350)

        # 톨게이트 구간좌표
        find_blue_line_s = (210, 1216)
        find_blue_line_e = (209, 1125)

        # 음영구간 구간좌표
        lane_detect_s = (201, 1070)
        lane_detect_e = (-3, 973)
        
        rate = rospy.Rate(30)
        while not rospy.is_shutdown():

            if self.is_gpson == True:
                self.recong_msg = 'basic'
            else:
                self.recong_msg = 'lanedetect'

            # if self.is_gps==True:
            #     self.recong_msg = 'basic'
            # else:
            #     self.recong_msg = 'lanedetect'

            # if self.is_gps==False:
            #     self.recong_msg = 'lanedetect'
            
            # # 톨게이트 구간
            # dis = sqrt(pow(self.current_postion.x - find_blue_line_s[0], 2) + pow(self.current_postion.y - find_blue_line_s[1], 2))
            # if dis < 5:
            #     self.recong_msg = 'tollgate'
            # dis = sqrt(pow(self.current_postion.x - find_blue_line_e[0], 2) + pow(self.current_postion.y - find_blue_line_e[1], 2))
            # if dis < 5:
            #     self.recong_msg = 'basic'
            
            # # 음영 구간
            # dis = sqrt(pow(self.current_postion.x - lane_detect_s[0], 2) + pow(self.current_postion.y - lane_detect_s[1], 2))
            # if dis < 5:
            #     self.recong_msg = 'lanedetect'
            # dis = sqrt(pow(self.current_postion.x - lane_detect_e[0], 2) + pow(self.current_postion.y - lane_detect_e[1], 2))
            # if dis < 5:
            #     self.recong_msg = 'basic'

            rospy.loginfo(self.recong_msg)
            self.recong_pub.publish(self.recong_msg)

            rate.sleep()

    def odom_callback(self,msg):
        self.is_odom=True
        odom_quaternion=(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,msg.pose.pose.orientation.z,msg.pose.pose.orientation.w)
        _,_,self.vehicle_yaw=euler_from_quaternion(odom_quaternion)
        self.current_postion.x=msg.pose.pose.position.x
        self.current_postion.y=msg.pose.pose.position.y

    def navsat_callback(self, gps_msg):

        self.lat = gps_msg.latitude
        self.lon = gps_msg.longitude
        self.alt = gps_msg.altitude
        self.e_o = gps_msg.eastOffset
        self.n_o = gps_msg.northOffset
        print(gps_msg.status)

        if gps_msg.status == 0:
            print("can not find gps")
            self.is_gpson = False
        else:
            self.is_gpson = True      

        self.is_gps=True

if __name__ == '__main__':
    try:
        recong = recong_pub()
    except rospy.ROSInterruptException:
        pass
